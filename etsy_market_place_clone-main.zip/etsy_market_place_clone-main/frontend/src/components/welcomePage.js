import React from "react";

function welcomePage() {
  return <div>welcomePage</div>;
}

export default welcomePage;
