const config = {
  mongoDB:
    "mongodb+srv://admin:admin123@clusterlab2.c3mj9.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
};

module.exports = config;
